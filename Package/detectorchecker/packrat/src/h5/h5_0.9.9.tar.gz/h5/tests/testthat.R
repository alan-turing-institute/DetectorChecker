library(testthat)
library(h5)

test_check("h5")
